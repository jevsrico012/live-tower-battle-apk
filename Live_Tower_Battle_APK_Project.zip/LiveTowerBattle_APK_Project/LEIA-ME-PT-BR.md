# Live Tower Battle — projeto Android para gerar APK

Este projeto cria um app Android simples que abre o jogo hospedado em:
https://tiktok-live-interactive-game-bwx2.onrender.com

O app usa WebView em modo de tela cheia, com JavaScript e armazenamento web ativados para permitir que a interface e o Socket.IO do jogo funcionem. O servidor precisa continuar online; o APK não inclui nem substitui o servidor.

## Como gerar o APK usando apenas o celular

1. Baixe e extraia este ZIP no celular.
2. Crie um repositório NOVO e público no GitHub, por exemplo `live-tower-battle-apk`. Não use o repositório que está ligado ao Render, para não disparar implantações desnecessárias.
3. Envie os arquivos e pastas extraídos para a raiz desse novo repositório, mantendo a pasta `.github/workflows/build-apk.yml`. No GitHub pelo navegador, use **Add file → Upload files**; se o navegador não permitir selecionar pastas, use o modo de site para computador ou um gerenciador de arquivos que permita selecionar todos os itens e pastas.
4. Após confirmar o commit na branch `main`, abra a aba **Actions** do repositório. O fluxo **Build Live Tower Battle APK** deve iniciar automaticamente.
5. Abra a execução mais recente concluída com sucesso e, na seção **Artifacts**, toque em `Live-Tower-Battle-APK` para baixar o ZIP do artefato.
6. Extraia o ZIP baixado; dentro estará `app-debug.apk`. Toque nele para instalar. Se o Android perguntar, permita a instalação dessa fonte para o navegador/gerenciador de arquivos que você usou.

Se o fluxo não iniciar, entre em Actions e habilite workflows para o repositório; depois execute **Build Live Tower Battle APK → Run workflow**.

## Limitações

- Esta é uma versão debug para uso pessoal, não um APK assinado para publicar na Play Store.
- A tela cheia esconde temporariamente as barras do Android; deslizar a partir da borda pode mostrá-las.
- A conexão real com curtidas, presentes e comentários depende da integração do servidor com uma LIVE ativa. A tela abrir não prova por si só que os eventos do TikTok estão funcionando.
- O Render gratuito pode suspender o serviço quando estiver ocioso, e o primeiro acesso pode demorar.
